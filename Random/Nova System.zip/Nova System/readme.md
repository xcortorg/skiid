### Wichtig ###


### Um den bot zu nutzen müsst Ihr bei License. DirectLeaks oder was auch sein kann Directleaks stehen. ansonsten startet der bot nicht. ###


### Wichtig stellt bei commands usw die Permissions ein ### bei hilfe gerne eine dm an _protec. ###

_protec.